#include "main.h"
#include "lemlib/api.hpp" // IWYU pragma: keep
#include <algorithm>
#include "robodash/api.h"
#include "robodash/views/console.hpp"
#include "robodash/views/selector.hpp"
#include "chassisInitialize.cpp"
#include "devices.cpp"
//creating a console 
using rd::Console;

Console console;

//AUTONS

//forward/back tuning pid auton
void lateralPIDTune() {
    console.println("Running Auton:Lateral PID!");
     // set position to x:0, y:0, heading:0
   // chassis.setPose(0, 0, 0);
    // turn to face heading 90 with a very long timeout
   // chassis.turnToHeading(90, 100000);
}

//turning tuning pid auton
void turningPIDTune(){
    console.println("Running Auton:Turning PID!");
     // set position to x:0, y:0, heading:0
   // chassis.setPose(0, 0, 0);
    // move 48" forwards
   // chassis.moveToPoint(0, 48, 10000);
} 

void runGIF(){

}

//ACTUAL SELECTOR
rd::Selector selector
({{"lateralPIDTune", &lateralPIDTune},
{"turningPIDTune", &turningPIDTune},
{"runGIF", &runGIF}
});