#include "main.h"
using pros::E_CONTROLLER_DIGITAL_DOWN;
using pros::E_CONTROLLER_DIGITAL_L2;

//Initialize Intake
pros::MotorGroup intake({7, -8});

//Initialize Pneumatics
pros::adi::DigitalOut backWings ('A');
pros::adi::DigitalOut wingsR ('B');
pros::adi::DigitalOut wingsL ('C');
pros::adi::DigitalOut hang1 ('D');
pros::adi::DigitalOut hang2 ('E');

//initialize controller
pros::Controller controller(pros::E_CONTROLLER_MASTER);
 	
//toggle for wings
bool backWingsToggle = false;
bool wingsLToggle = false;
bool wingsRToggle = false;
 
//intake driver control function
 void intakeControl(){
    if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
			intake.move_voltage(1200);
			} else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1)) {
			intake.move_voltage(-1200);
			} else {
			intake.move_voltage(0);
			}
 }

//Hang Driver Control Function
void hangControl(){
    if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_UP)){
			hang1.set_value(true);
		}
                if (controller.get_digital_new_press(E_CONTROLLER_DIGITAL_DOWN)) {
                        hang1.set_value(false);
			hang2.set_value(false);
                }
}

//BackWings Driver Control Function
void backWingsControl(){
     if(controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_A)){
					backWingsToggle = !backWingsToggle;
					backWings.set_value(backWingsToggle);
				}
}

//Left Wing Driver Control Function
void wingsLControl(){
if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_R2)) {
					wingsLToggle = !wingsLToggle;
					wingsL.set_value(wingsLToggle);
				}
}

//Right Wing Driver Control Function
void wingsRControl(){
                                if (controller.get_digital_new_press(
                                        E_CONTROLLER_DIGITAL_L2)) {
                                        wingsRToggle = !wingsRToggle;
					wingsR.set_value(wingsRToggle);
                                }
}